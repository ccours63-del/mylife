package com.mylife.usage

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Process
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.ProtocolException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Sync {
    private const val GIST_DESC = "my-life-app-data"
    private const val MAIN_FILE = "my-life.json"
    private const val PHONE_FILE = "phone-usage.json"

    fun prefs(ctx: Context) = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        if (mode == AppOpsManager.MODE_DEFAULT) {
            return ctx.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS") ==
                PackageManager.PERMISSION_GRANTED
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** milliseconds in foreground per package, between [from] and [to] */
    private fun usage(ctx: Context, from: Long, to: Long): Map<String, Long> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(from, to)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val seen = HashSet<String>()
        val res = HashMap<String, Long>()
        fun add(key: String, ms: Long) {
            if (ms <= 0) return
            val pkg = key.substringBefore('/')
            res[pkg] = (res[pkg] ?: 0L) + ms
        }
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            val key = pkg + "/" + (e.className ?: "")
            val t = e.timeStamp
            when (e.eventType) {
                1 -> { // ACTIVITY_RESUMED
                    open[key]?.let { add(key, t - it) }
                    open[key] = t
                    seen.add(key)
                }
                2 -> { // ACTIVITY_PAUSED
                    val st = open.remove(key)
                    if (st != null) add(key, t - st)
                    else if (!seen.contains(key)) add(key, t - from) // was already open at start
                    seen.add(key)
                }
                16, 26 -> { // screen off / shutdown: close everything
                    for ((k, st) in open) add(k, t - st)
                    open.clear()
                }
            }
        }
        for ((k, st) in open) add(k, to - st)
        return res
    }

    private fun dayStart(daysAgo: Int): Calendar {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return c
    }

    private fun label(pm: PackageManager, pkg: String): String = try {
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun build(ctx: Context, daysBack: Int): JSONObject {
        val pm = ctx.packageManager
        val skip = HashSet<String>()
        skip.add("com.android.systemui"); skip.add("android"); skip.add(ctx.packageName)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (r in pm.queryIntentActivities(home, 0)) skip.add(r.activityInfo.packageName)
        } catch (e: Exception) { }
        val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val now = System.currentTimeMillis()
        val days = JSONObject()
        for (i in 0 until daysBack) {
            val s = dayStart(i)
            val n = dayStart(i - 1)
            val from = s.timeInMillis
            val to = minOf(n.timeInMillis, now)
            if (to <= from) continue
            val raw = usage(ctx, from, to)
            val byName = HashMap<String, Long>()
            var total = 0L
            for ((pkg, ms) in raw) {
                if (skip.contains(pkg)) continue
                total += ms
                if (ms >= 60_000L) {
                    val nm = label(pm, pkg)
                    byName[nm] = (byName[nm] ?: 0L) + ms
                }
            }
            val apps = JSONObject()
            for ((nm, ms) in byName.entries.sortedByDescending { it.value }.take(25)) {
                apps.put(nm, Math.round(ms / 60000.0).toInt())
            }
            val d = JSONObject()
            d.put("tot", Math.round(total / 60000.0).toInt())
            d.put("apps", apps)
            days.put(df.format(Date(from)), d)
        }
        return JSONObject().put("days", days)
    }

    private fun http(method: String, url: String, token: String, body: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 20000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "my-life-usage")
        if (body != null) {
            try {
                c.requestMethod = method
            } catch (e: ProtocolException) {
                c.requestMethod = "POST"
                c.setRequestProperty("X-HTTP-Method-Override", method)
            }
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        } else {
            c.requestMethod = method
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        c.disconnect()
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return text
    }

    private fun findGist(token: String): String {
        val arr = JSONArray(http("GET", "https://api.github.com/gists?per_page=100", token))
        for (i in 0 until arr.length()) {
            val g = arr.getJSONObject(i)
            if (g.optString("description") == GIST_DESC && g.optJSONObject("files")?.has(MAIN_FILE) == true) {
                return g.getString("id")
            }
        }
        throw RuntimeException("NOGIST")
    }

    private fun result(ctx: Context, ok: Boolean, msg: String): String {
        val e = prefs(ctx).edit().putString("msg", msg).putLong("msgTs", System.currentTimeMillis())
        if (ok) e.putLong("okTs", System.currentTimeMillis())
        e.apply()
        return msg
    }

    /** Reads today's usage and writes phone-usage.json into the same gist the web app syncs with. */
    @Synchronized
    fun run(ctx: Context): String {
        val p = prefs(ctx)
        val token = p.getString("token", "") ?: ""
        if (token.isEmpty()) return result(ctx, false, "أدخل رمز GitHub أولاً")
        if (!hasAccess(ctx)) return result(ctx, false, "صلاحية الاستخدام غير ممنوحة")
        try {
            var gid = p.getString("gist", "") ?: ""
            if (gid.isEmpty()) {
                gid = findGist(token)
                p.edit().putString("gist", gid).apply()
            }
            val fresh = build(ctx, 7)
            val newDays = fresh.getJSONObject("days")
            // keep older days that already exist in the cloud
            val merged = JSONObject()
            try {
                val g = JSONObject(http("GET", "https://api.github.com/gists/$gid", token))
                val f = g.optJSONObject("files")?.optJSONObject(PHONE_FILE)
                if (f != null) {
                    var content = f.optString("content", "")
                    if (f.optBoolean("truncated") || content.isEmpty()) {
                        content = http("GET", f.getString("raw_url"), token)
                    }
                    val old = JSONObject(content).optJSONObject("days")
                    if (old != null) for (k in old.keys()) merged.put(k, old.get(k))
                }
            } catch (e: Exception) {
                if (e.message?.contains("404") == true) {
                    p.edit().remove("gist").apply()
                    throw e
                }
            }
            for (k in newDays.keys()) merged.put(k, newDays.get(k))
            val keys = ArrayList<String>()
            for (k in merged.keys()) keys.add(k)
            keys.sort()
            while (keys.size > 120) merged.remove(keys.removeAt(0))
            val out = JSONObject().put("v", 1).put("updated", System.currentTimeMillis()).put("days", merged)
            val files = JSONObject().put(PHONE_FILE, JSONObject().put("content", out.toString()))
            http("PATCH", "https://api.github.com/gists/$gid", token, JSONObject().put("files", files).toString())
            val today = newDays.optJSONObject(newDays.keys().asSequence().maxOrNull() ?: "")
            val mins = today?.optInt("tot") ?: 0
            return result(ctx, true, "تمت المزامنة · اليوم ${mins / 60} س ${mins % 60} د")
        } catch (e: Exception) {
            val m = e.message ?: ""
            return result(
                ctx, false,
                when {
                    m.contains("401") -> "الرمز غير صالح أو منتهي"
                    m == "NOGIST" -> "لم أجد ملف المزامنة. فعّل المزامنة في تطبيق My Life أولاً بنفس الرمز"
                    m.contains("403") -> "تم تجاوز حد الطلبات، سأعيد المحاولة"
                    else -> "تعذّر الاتصال، سأعيد المحاولة"
                }
            )
        }
    }
}
