package com.mylife.usage

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var access: TextView
    private lateinit var tokenBox: EditText
    private val ui = android.os.Handler(android.os.Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(Color.parseColor(color))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(30))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.START
        }
        root.addView(text("My Life · استهلاك الهاتف", 22f, "#F5B544", true))
        root.addView(text("يقرأ وقت استخدامك ويرسله تلقائياً إلى تطبيق My Life كل 30 دقيقة.", 14f, "#8B94A5"))

        root.addView(text("1) رمز GitHub (نفس رمز المزامنة)", 15f, "#ECEFF4", true))
        tokenBox = EditText(this).apply {
            hint = "ghp_xxxxxxxx"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setText(Sync.prefs(this@MainActivity).getString("token", ""))
        }
        root.addView(tokenBox)
        root.addView(button("حفظ وربط") {
            val t = tokenBox.text.toString().trim()
            Sync.prefs(this).edit().putString("token", t).remove("gist").apply()
            SyncWorker.schedule(this)
            syncNow()
        })

        root.addView(text("2) صلاحية قراءة الاستخدام", 15f, "#ECEFF4", true))
        access = text("", 14f, "#8B94A5")
        root.addView(access)
        root.addView(button("منح صلاحية الاستخدام") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        root.addView(text("3) حتى لا يوقفه النظام", 15f, "#ECEFF4", true))
        root.addView(text("افتح إعدادات التطبيق ← البطارية ← «بلا قيود»، وفعّل «التشغيل التلقائي» إن وُجد (Xiaomi / Oppo / Samsung).", 13f, "#8B94A5"))
        root.addView(button("فتح إعدادات التطبيق") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(android.net.Uri.parse("package:$packageName"))
            )
        })

        root.addView(text("الحالة", 15f, "#ECEFF4", true))
        status = text("", 14f, "#4FC48B")
        root.addView(status)
        root.addView(button("مزامنة الآن") { syncNow() })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0D10"))
            addView(root)
        })
    }

    private fun syncNow() {
        status.text = "جارٍ المزامنة…"
        Thread {
            Sync.run(applicationContext)
            ui.post { refresh() }
        }.start()
    }

    private fun refresh() {
        val ok = Sync.hasAccess(this)
        access.text = if (ok) "✓ الصلاحية ممنوحة" else "✗ غير ممنوحة بعد: اضغط الزر وفعّل My Life Usage"
        access.setTextColor(Color.parseColor(if (ok) "#4FC48B" else "#F2726C"))
        val p = Sync.prefs(this)
        val ts = p.getLong("msgTs", 0L)
        val msg = p.getString("msg", "لم تتم مزامنة بعد") ?: ""
        val tm = if (ts > 0) " (" + SimpleDateFormat("HH:mm", Locale.US).format(Date(ts)) + ")" else ""
        status.text = msg + tm
        status.setTextColor(Color.parseColor(if (msg.startsWith("تمت")) "#4FC48B" else "#F5B544"))
    }

    override fun onResume() {
        super.onResume()
        refresh()
        val p = Sync.prefs(this)
        if (!(p.getString("token", "") ?: "").isEmpty()) {
            SyncWorker.schedule(this)
            if (Sync.hasAccess(this)) syncNow()
        }
    }
}
